STARCRAFT (RESOURCE PACK) v2.1 - READ ME
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
LEGAL STUFF:
This resource pack may not be altered or reuploaded without permission from the creator.
This pack is designed solely for use with the StarCraft (Star Trek Adventure) map which can be found here:
(https://www.planetminecraft.com/project/starcraft-star-trek-adventure/)


Please feel free to use this for yourself but it will make some mobs look and sound strange. Any bugs found, please report on the download page
- TheEmeraldArmour

-----------------------------------------------------------------------
https://www.planetminecraft.com/project/starcraft-star-trek-adventure/
-----------------------------------------------------------------------

MINECRAFT VERSION:
This pack is for Minecraft 1.12.2



--------------------------------------------------
PEOPLE WITHOUT WHOM THIS PACK WOULD NOT EXIST
--------------------------------------------------

TheEmeraldArmour

Zinzee

MineTrek

TrekCore.com

Lcars 47

Dark VO
